# Briefing for Grok — OPRAI Mercury Architect Pipeline (2026-06-23)

## TL;DR

Мы превратили OPRAI из «голого Mercury chat» в **Mercury-only architect-programmer pipeline** с skills, gates и фазами. **Roadmap v3** — лучший проверенный roadmap (Stage 1). **Architect Pipeline** (Stage 2) инфраструктурно работает (80 tests, golden path cache). Повторный roadmap через `Phase=PLAN` сегодня **не записал файл** — агент зациклился на reads (40 tool steps), это известное поведение Mercury без evidence bundle.

---

## Что было (проблема)

| Симптом | Причина |
|---------|---------|
| Generic marketing в roadmap | Нет skills / gates |
| `req_2026*`, `tokens_input` в §5 Metrics | Фабрикация без чтения trace |
| «Файл создан» без файла на диске | Нет fail-closed deliverable gate |
| Re-read loops | Нет ordered workflow + evidence bundle |

**Вывод Grok был верен:** Mercury ≠ архитектор сам по себе; нужна надстройка OPRAI.

---

## Stage 1 — Skill stack (8 артефактов)

**Core (always-on):** `dllm-mercury`, `oprai-core`  
**Domain:** audit, roadmap, consult, implement-stamp  
**Safety:** `extract_llm_trace_metrics.py`, fabrication verifier в `deliverable_validator`

**Roadmap evolution:**

| Version | Метод | Строк | §5 Metrics | Verified |
|---------|-------|-------|------------|----------|
| v1 | synthesis/chat | 163 | частично выдумано | слабо |
| v2 | agent loop | 133 | **фабрикация** `req_2026*` | да |
| **v3** | agent + ordered reads + trace snippet | **105** | **реальные UUID** | да |

v3 evidence: `MERCURY2_ROADMAP_V3_VERIFY.json`, `change_ledger` stamp `mercury_skill_stack_stage1`.

---

## Stage 2 — Mercury Architect Pipeline

### Архитектура (3 слоя)

1. **Cognitive** — skills + policy (`Phase=DESIGN|PLAN|IMPLEMENT|VERIFY|REVIEW`)
2. **Orchestration** — `TaskRunner` (checkpoints, phase budgets)
3. **Quality** — `plan_validator`, TDD gate, diff budget, VERIFY.json schema

### Mercury-only

- `OPRAI_MERCURY_ONLY=1` (default) — `cursor_cli` blocked в `llm_router`
- Prod path: только `LLM_PROVIDER=inception`

### Новые skills

`mercury-architect`, `mercury-tdd`, `mercury-verify`, `mercury-code-review`

### Golden path (lab)

Task: TTL cache для `codebase_context.load_index()`  
Script: `run_architect_pipeline_golden.py` → **PASS**  
Evidence: `ARCHITECT_PIPELINE_GOLDEN.json`, 80 pytest pass

---

## Roadmap через новую архитектуру — проверка 2026-06-23

**Вопрос:** проверяли ли roadmap через Architect Pipeline?  
**Ответ:** v3 — **до** pipeline (Stage 1 only). v4 — **первая попытка** через `Phase=PLAN`.

### v4 run (`run_roadmap_v4_architect.py`)

| Check | Result |
|-------|--------|
| Mercury-only | yes |
| Skill injection: dllm-mercury + oprai-core + mercury-roadmap | yes (2903 chars) |
| Phase=PLAN budgets (40 steps, 50 gates) | applied |
| deliverable on disk | **no** |
| tool_steps | 40 (max) → `agent exceeded max steps` |
| fabrication | n/a (no file) |

**Диагноз:** тот же класс проблем что v1/v2 до ordered workflow — агент тратит budget на reads, не доходит до `write_file`. Stage 1 fix (ordered 8-step prompt + pre-extracted `_trace_snippet.md`) для v3 работал; v4 без изменения prompt structure + новые phase gates → loop.

**Повтор v3 script сегодня:** тоже fail (40 steps) — возможно transient Mercury или stricter validation после pipeline.

### Что architect pipeline **доказал** для roadmap

- Skills inject correctly under `Phase=PLAN ROADMAP`
- Mercury-only routing works
- Gates не пропускают phantom success (fail-closed при отсутствии файла)
- TaskRunner различает ROADMAP.md vs PLAN.md (plan_validator только для PLAN artifacts)

### Что ещё нужно для стабильного roadmap

1. Evidence bundle pre-step (`build_evidence_bundle.py`) — как v3 trace snippet
2. TaskRunner message templates с жёстким порядком tools
3. Optional: `Phase=PLAN` + `ROADMAP mode` → skip plan_validator (fixed in task_runner)

---

## Рекомендация Grok / operator

**Для roadmap:** использовать проверенный паттерн v3:
```
ordered reads → read trace snippet → write_file
INCEPTION_MAX_GATE_TURNS=50 forced in script
```

**Для implement tasks:** полный pipeline DESIGN → PLAN → IMPLEMENT → VERIFY → REVIEW

**Не делать:** один длинный chat; Cursor CLI (Mercury-only); auto-promote lab→prod

---

## Key files

| Artifact | Path |
|----------|------|
| Pipeline docs | `docs/MERCURY_ARCHITECT_PIPELINE.md` |
| Best roadmap | `oprai_lab/.../MERCURY2_ROADMAP_vs_CURSOR_CLI_20260623_v3.md` |
| v4 verify (fail) | `oprai_lab/.../MERCURY2_ROADMAP_V4_VERIFY.json` |
| Golden path | `oprai_lab/.../ARCHITECT_PIPELINE_GOLDEN.json` |
| Ledger | `oprai_lab/.../change_ledger.jsonl` |

---

## One-liner for Grok

«Мы не “улучшили промпт” — мы построили Mercury-only конвейер (skills + fail-closed gates + фазы RECON→REVIEW). Roadmap v3 доказал anti-fabrication metrics; Architect Pipeline доказал implement/verify path на cache task; повтор roadmap через Phase=PLAN показал что Mercury всё ещё нуждается в ordered workflow + evidence bundles — инфраструктура ловит сбои, модель не “архитектор” без неё.»
